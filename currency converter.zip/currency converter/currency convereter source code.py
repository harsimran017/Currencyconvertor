from tkinter import *

converter=Tk()
converter.geometry("600x500",)

converter.title("currency converter")

OPTIONS={
    		
     "Australian dollor":52.08,
     
     "united state dollor":73.015,
    "British pound":95.274,
     "Japanees yen":0.693,
     "Singapore dollor":53.96,
     "Taiwan dollor":2.5512,
     "Euro":86.245,
     "Hong kong dollor":9.4212,
     "Chinese yuan":10.94,
     "algerian dinar":0.521,
     "Argentine peso":0.9456,
    " Bangladeshi taka" :0.861,
     "Brunei dollor":53.9685,
     "Brazilian real":13.1992,
     "canadian dollor":55.6559,
     "Egyptian pound":4.6652,
     "New zealand dollor":48.6784,
     "Sri lankan rupee":0.3962
     
    
     
    }
def ok():
    price=rupees.get()
    answer=variable.get()
    DICT=OPTIONS.get(answer,None)
    
    converted=float(price)/float(DICT)
    result.delete(1.0,END)
    result.insert(INSERT,"price In ",INSERT,answer,INSERT," = ",
                  INSERT,converted)
    
Name= Label(converter,text="CURRENCY",
              font=("arial",25,"bold"),fg="dark green")
Name.grid(row=0,column=0)
Name= Label(converter,text="CONVERTER",
              font=("arial",25,"bold"),fg="dark green")
Name.grid(row=0,column=1,ipadx=10)

india=Label(converter,text="indian rupee:" ,
            font=("arial",15,"bold"),fg="blue",bg="green")
india.grid(row=1,column=0)
rupees=Entry(converter,font=("calibri",20),bg="pink")
rupees.grid(row=1,column=1)
choice=Label(converter,text="choose country:",
            font=("arial",15,"bold"),fg="blue",bg="green")
choice.grid(row=2,column=0)
variable = StringVar(converter)
variable.set(None)
option=OptionMenu(converter,variable,*OPTIONS)
option.grid(row=2,column=1,sticky="ew")
button=Button(converter,text="Converte",fg="green",
              font=("calibri,20"),bg="pink",command=ok)
button.grid(row=3,column=1)
var=Label(converter,text ="converted amount : ",
          font=("arial",15,"bold"),fg="blue",bg="green")
var.grid(row=4,column=0)
result=Text(converter,height=5,width=50,font=("arial",10,"bold"),bd=2,bg="pink")
result.grid(row=4,column=1,padx=3)



mainloop()
